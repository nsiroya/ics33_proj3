import re, traceback, keyword

def pnamedtuple(type_name, field_names, mutable = False, defaults = {}):
    def show_listing(s):
        for line_number, line_text in enumerate( s.split('\n'),1 ):  
            print(f' {line_number: >3} {line_text.rstrip()}')

    # put your code here
    # bind class_definition (used below) to the string constructed for the class



    # For debugging, uncomment next line, which shows source code for the class
    # show_listing(class_definition)
    
    # Execute the class_definition (a str), in a special name space; then bind
    #   its source_code attribute to class_definition; after try/except return the
    #   class object created; if there is a syntax error, list the class and
    #   also show the error
    name_space = dict( __name__ = f'pnamedtuple_{type_name}' )      
    try:
        exec(class_definition,name_space)
        name_space[type_name].source_code = class_definition
    except (TypeError,SyntaxError):          
        show_listing(class_definition)
        traceback.print_exc()
    return name_space[type_name]


    
if __name__ == '__main__':
    # Test simple pnamedtuple below in script: Point=pnamedtuple('Point','x,y')

    #driver tests
    import driver  
    driver.default_file_name = 'bscp3W20.txt'
#     driver.default_show_exception_message= True
#     driver.default_show_traceback= True
    driver.driver()
